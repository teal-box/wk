from myCounter import myTaskCounter
from fpdf import FPDF
class PDF(FPDF):
    taskid = myTaskCounter()
    def header(self):
        # Select Arial bold 15
        self.set_font('arial', 'B', 13)
        # Move to the right
        self.cell(80)
        # Framed title
        self.set_text_color(0,0,0)
        self.cell(5, 5, 'Golden Sheet Validation Report', 0, 0, 'C')
        # Line break
        self.ln(15)
        self.line(5,13,200,13)

    def footer(self):
        # Go to 1.5 cm from bottom
        self.set_y(-15)
        # Select Arial italic 8
        self.set_font('Arial', 'I', 8)
        # Print centered page number
        self.set_text_color(0,0,255)
##        self.ln(15)
        self.line(5,-5,5,-5)
        self.cell(0, 10, 'Page %s' % self.page_no(), 0, 0, 'R')

    def writeLine(self, txt, color="BLACK", size=9.0):
        if color == "BLACK":
            color = (0,0,0)
        elif color == "RED":
            color = (210, 4, 45)
        elif color == "BLUE":
            color = (0,0,255)
        elif color == "GREEN":
            color = (0,255,0)
##        elif color == "RED":
##            color = (255,0,0)
##        elif color == "RED":
##            color = (255,0,0)
        self.current_x = self.get_x()
        self.current_y = self.get_y()
        self.set_xy(self.current_x, self.current_y)
        self.set_font('arial', '', size=size)
        self.set_text_color(*color)
        self.multi_cell(w=0, h=5.0, align='L',txt=txt)

    def writePass(self, size=12.0):
        txt = "Pass."
        self.current_x = self.get_x()
        self.current_y = self.get_y()
        self.set_xy(self.current_x, self.current_y)
        self.set_font('arial', 'B', size)
        self.set_font('', 'U', size)
        self.set_text_color(50, 205, 50)
        self.multi_cell(w=0, h=5.0, align='R', txt=txt, border=0)

    def writeFail(self, size=12.0):
        txt = "Fail."
        self.current_x = self.get_x()
        self.current_y = self.get_y()
        self.set_xy(self.current_x, self.current_y)
        self.set_font('arial', 'B', size)
        self.set_font('', 'U', size)
        self.set_text_color(210, 4, 45)
##        self.write(5,txt)
        self.multi_cell(w=0, h=5.0, align='R', txt=txt, border=0)

    def writeTask(self, task, status):
        # always start from new line and should be in the form of
        # Task ID: Description
        #                      Pass/Fail
        taskid = next(self.taskid)
        self.ln()
        self.current_x = self.get_x()
        self.current_y = self.get_y()
        self.set_xy(self.current_x, self.current_y)
        self.set_font('arial', 'B', size=10.0)
        self.set_font('', 'U', size=10.0)
        self.set_text_color(0, 0, 0)
        # write task ID
        self.write(5, taskid)
        # write white-space to remove underline
        self.set_font('', '', size=10.0)
        self.write(5, " ")
        # write task details
        self.writeLine(txt=task, color="BLACK", size=9.0)
        # write task status Bold
        if status.lower() == "fail" or status.lower() == "false" or status.lower() == "f":
            self.writeFail(size=10.0)
        elif status.lower() == "pass" or status.lower() == "true" or status.lower() == "t":
            self.writePass(size=10.0)
        pass

pdf = PDF()

# pdf.set_auto_page_break(True, margin=10)

txt = "This method is used to render the page header. It is automatically called by add_page and should not be called directly by the application."
left_margin = 5
top_margin =  5
right_margin = 5
pdf.set_margins(left=left_margin, top=top_margin, right=right_margin)
pdf.add_page()

pdf.writeTask("Checking McD_HHOT", status="Pass")
pdf.writeTask("Checking McD_HH", status="FAIL")
pdf.writeTask("Checking McDOT", status="pass")
pdf.writeTask("Checking MHHOT", status="F")


pdf.add_page()

pdf.writeTask("Checking McD_HHOT", status="Pass")
pdf.writeTask("Checking McD_HH", status="FAIL")
pdf.writeTask("Checking McDOT", status="pass")
pdf.writeTask("Checking MHHOT", status="F")

pdf.output(r"c:\temp\text.pdf", 'F')