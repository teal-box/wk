#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
from sdwan import *
from myXLS import *
from sdwan_utils.utils import *
wkGS = r"C:\00-Projects\00-WK\Firewall_rule_branch_v1.2.xlsx"
import functools
import time, json

c90 = mySDWAN(vManage="192.168.86.27", username = "admin", passcode="VMware1!", gs="")


wb = fast_openpyxl(wkGS)
ClassMaps = wb[1]["sheet_ClassMap"]


for item in ClassMaps:
    entries = classItemParse(item,'queue')
    payload = createListPayload(item['name'], 'class', entries)
    t = c90.post(api='/template/policy/list/class', method="POST", payload=payload)
def main():
    pass

if __name__ == '__main__':
    main()
