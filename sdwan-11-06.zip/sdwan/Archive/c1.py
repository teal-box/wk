import click

#-------------------------------------------------------------------------------



@click.group()
def cli():
    """Command line tool for Monitoring and Configuring CISCO SD-WAN fabric.
    """
    pass

@click.command()
@click.option("--name", "-n", default="IOSv")
def list_devices(name):
    click.echo("Listing of CISCO SD-WAN devices\n{}".format(name))


@click.command()
def template_list():
    click.echo("my Templates are fix for SD-WAN implementation\n")


@click.command()
def system_status():
    click.echo("System is running very Slow\n")


class MyClass:
    def __init__(self):
        self.foo = "FOO"

    def do_something(self):
        click.echo(f"Doing something with {self.foo}")

my_decorator = click.make_pass_decorator(MyClass, ensure=True)

@click.command()
@my_decorator
@click.option("--name","-n", default="ashok")
def my_command(ctx,name):
    """ Ysed to run class functon"""
    ctx.do_something()



cli.add_command(list_devices)
cli.add_command(template_list)
cli.add_command(system_status)
cli.add_command(my_command)

def main():
    cli()
    pass

if __name__ == '__main__':
    main()


@command()
def say():
    print("Hello CLICK")