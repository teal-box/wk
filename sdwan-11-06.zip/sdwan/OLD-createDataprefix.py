import click
import os, csv
from sdwan import *
from hc_SearchClass import *
from tabulate import tabulate
from sdwan_utils.utils import *

@click.command()
@click.option("--vmanage",  '-v', prompt="vManage IP", default='10.10.20.90', required=True)
@click.option("--username", '-u', prompt="vManage Username", default='admin', required=True)
@click.option("--password", '-p', prompt="Password", hide_input=True, required=True, default='C1sco12345')
@click.option("--dataprefixfile", '-d', prompt="Dataprefix File", default='gs/dataprefixIPv4.csv', required=True)
def cli(vmanage, username, password, dataprefixfile):

    # check file exist or not
    try:
        os.lstat(dataprefixfile)
    except FileNotFoundError as e:
        print("File not found!! %s" % dataprefixfile)
        raise SystemExit()

    c90 = mySDWAN(vManage=vmanage,username=username, passcode=password)
    hcs = hcSearch(vManage=vmanage,headers=c90.headers)
    allDT = hcs.getDataprefix()
    with open(dataprefixfile, "r") as f:
        _ = f.readline() # ingore first fline
        lines = f.readlines()
        for line in lines:
            line = line.strip().split(",", maxsplit=1)
##            print(line)
            name = line[0]
            value = line[1]
            if not checkIPStr(value):
                print("Not a valid List %s : %s" % (name,value))
            else:
                print("Valid data for list, creating list %s" % name)
                c90.createDataPrefix(name, desc=name+" Created by API", objType="dataprefix", ipStr=value)

if __name__ == "__main__":
    cli()