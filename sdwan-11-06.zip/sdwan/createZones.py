import click
import os, csv
from sdwan import *
from hc_SearchClass import *
from tabulate import tabulate
from sdwan_utils.utils import *

@click.command()
@click.option("--vmanage",  '-v', prompt="vManage IP", default='10.10.20.90', required=True)
@click.option("--username", '-u', prompt="vManage Username", default='admin', required=True)
@click.option("--password", '-p', prompt="Password", hide_input=True, required=True)
@click.option("--zonefile", '-z', prompt="Dataprefix File", default='gs/zoneFile.csv', required=True)
def cli(vmanage, username, password, zonefile):

    # check file exist or not
    try:
        os.lstat(zonefile)
    except FileNotFoundError as e:
        print("File not found!! %s" % zonefile)
        raise SystemExit()
##
    c90 = mySDWAN(vManage=vmanage,username=username, passcode=password)
##    hcs = hcSearch(vManage=vmanage,headers=c90.headers)
    with open(zonefile, "r", encoding='utf-8-sig') as f:
        for item in csv.DictReader(f):
            print(item['name'])
            zpayload = zoneItemParse(item)
            payload = createListPayload(item["name"], "zone", zpayload)
            print(payload)
            t = c90.post(api='/template/policy/list/zone', method="POST", payload=payload, name=item['name'])

if __name__ == "__main__":
    cli()