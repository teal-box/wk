#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
from sdwan import *
from myXLS import *
##wkGS = r"C:\00-Projects\00-WK\Firewall_rule_branch_v1.2.xlsx"
import functools
import time, json
from sdwan_utils.utils import *
from pathlib import Path

def main():
    wkGS = Path("gs" / "Firewall_rule_branch_v1.2.xlsx")
    wb =    fast_openpyxl(wkGS)
    zones = wb[1]["sheet_Zone"]
    ports = wb[1]["sheet_Port"]
    dataPrefix = wb[1]["sheet_List"]

    c90 = mySDWAN(vManage="10.10.20.90", username = "admin", passcode="C1sco12345", gs="")

    print("Creating of Zones in the SD-WAN")
    for item in zones:
        zpayload = zoneItemParse(item)
        payload = createListPayload(item["name"], "zone", zpayload)
        t = c90.post(api='/template/policy/list/zone', method="POST", payload=payload, name=item['name'])

    print("Creating Port List in the SD-WAN")
    for item in ports:
        parseItem =  portItemParse(item, "port" )
        payload=createListPayload(item['name'], dtype="port", entries=parseItem)
        t = c90.post(api='/template/policy/list/port', method="POST", payload=payload, name=item['name'])

    # dataPrefix is a list of objects/records
    print("Creating DataPrefix List in the SD-WAN")
    for counter, item in enumerate(dataPrefix):
        if not checkIPStr(item['Value']):
            print("Not a valid List %s" % item.get('Name', None))
            print("Removing entry from the list")
            dataPrefix.pop(counter)
        else:
            print("Valid data for list, creating list %s" % item['Name'])
            c90.createDataPrefix(item['Name'], desc=item['Name']+" Created by API", objType="dataprefix", ipStr=item['Value'] )

    ClassMaps = wb[1]["sheet_ClassMap"]
    print("Creating Classmaps in the SD-WAN")
    for item in ClassMaps:
        entries = classItemParse(item,'queue')
        payload = createListPayload(item['name'], 'class', entries)
        t = c90.post(api='/template/policy/list/class', method="POST", payload=payload, name=item['name'])

    pass

if __name__ == '__main__':
    main()
