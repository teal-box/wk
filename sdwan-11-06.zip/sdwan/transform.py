import requests
from uuid import UUID
import json

def transform(data, key):
    # data must be a list of dict
    if (not isinstance(data,(list,))) and len(data) == 0 and key not in data[0]:
        print("Data must be list of dict and atlead one item")
        return None
    temp = {}
    for item in data:
        temp.setdefault(item[key], item)
    return temp

def testUUID(tstUUID):
    from uuid import UUID
    try:
        _ = UUID(tstUUID)
    except ValueError:
        return False
    return True

def getID(data, key):
    # data must be dict
    if not isinstance(data, (dict,)):
        print("Data is not in json format")
        return None
    if key in data:
        # get a list of all
        keys = []
        [keys.append(k) for k in data[key].keys() if 'id' in k or 'Id' in k]
        # check which id having uuid value.
        for tkey in keys:
            if testUUID(data[key][tkey]):
                return data[key][tkey]

def getCSVPayload(templateId):
    return json.dumps({"templateId":templateId,"isEdited":False,"isMasterEdited":False} )

##
##url = "https://192.168.86.27/dataservice/template/device"
##
##payload={}
##headers = {
##  'Accept': 'application/json',
##  'Cookie': 'JSESSIONID=OMs_48dYqSdjawxrVIl3tDeWJs03in6KI1Ltuyb_.84b786ff718daa08d4f80c1190459073d57c53ae14ae165057d48a581f67322b',
##  'X-XSRF-TOKEN': '7FDE6E9BDB706D0265062E9922349EA5A12278F4F4DC55BC39D9F0714476CE7F4F98A2D5A46C61334D26D7C0CB0A21796145'
##}
##
##response = requests.request("GET", url, headers=headers, data=payload, verify=False)
##
##data = response.json()
##templates = transform(data['data'], 'templateName')
##
##url = "https://192.168.86.27/dataservice/system/device/vedges"
##response = requests.request("GET", url, headers=headers, data=payload, verify=False)
##data = response.json()
##vedges = transform(data['data'], 'templateName')
##url = "https://192.168.86.27/dataservice/template/policy/list"
##response = requests.request("GET", url, headers=headers, data=payload, verify=False)
##data = response.json()
##dataPrefix = transform(data['data'], 'name')
### print(dataPrefix)
##
##
##url = "https://192.168.86.27/dataservice/template/policy/list/localapp"
##response = requests.request("GET", url, headers=headers, data=payload, verify=False)
##data = response.json()
##applications = transform(data['data'], 'name')
##tId = getID(templates, 'my-c8000v')
##payload = getCSVPayload(tId)
##url = "https://192.168.86.27/dataservice/template/device/config/exportcsv"
##response = requests.request("POST", url, headers=headers, data=payload, verify=False)
##data = response.json()
##
##
##
