#-------------------------------------------------------------------------------
# Name:        SecurityPolicyV3.py
#-------------------------------------------------------------------------------
from myXLS import *
import json
from pathlib import Path
from hc_SearchClass import *
from sdwan import *
##################

def baseSPolicyPayload(policyName, policyDescription="", hslServerIp="", hslVrf=100, hslPort=2055, loggingVpn=100, loggingServerIp=""):
    return \
    {
        "policyName": policyName,
        "policyDescription": policyDescription,
        "policyMode": "security",
        "policyType": "feature",
        "policyUseCase": "custom",
        "policyDefinition": {
            "assembly": [],
            "settings": {
                "zoneToNozoneInternet": "deny",
                "highSpeedLogging": {
                    "serverIp": hslServerIp,
                    "vrf": hslVrf,
                    "port": hslPort
                },
                "logging": [
                    {
                        "vpn": loggingVpn,
                        "serverIP": loggingServerIp
                    }
                ],
                "failureMode": "open"
            }
        }
    }

def createSecurityPolicy(c90, securityGS="securityGS.csv"):
    srch = hcSearch(c90.vManage, c90.headers)
    status, data = fast_openpyxl(securityGS)
    sPolicy = data['sheet_SecurityPolicy']

    k = list (sPolicy[0].keys())
    if [ 'Name', 'Section','Value'] != sorted(k):
        print("Core template format is not matching, !!!")
    policy = {}
    hsl = {}
    slogging = {}
    policyDef = {}
    zoneBasedFW = []
    urlFiltering = []
    intrusionPrevention = []
    for item in sPolicy:
        if item['Section'] == 'policy':
    ##        print(item)
            policy.setdefault(item['Name'], item['Value'])

        if item['Section'] == 'settings.highSpeedLogging':
            hsl.setdefault(item['Name'], item['Value'])

        if item['Section'] == "settings.logging":
            slogging.setdefault(item['Name'], item['Value'])

        if item['Section'] == "policyDefinition" and item['Name'] ==  "zoneBasedFW":
            zoneBasedFW.append(item['Value'])

        if item['Section'] == "policyDefinition" and item['Name'] ==  "urlFiltering":
            urlFiltering.append(item['Value'])

        if item['Section'] == "policyDefinition" and item['Name'] ==  "intrusionPrevention":
            intrusionPrevention.append(item['Value'])


    policyDef.setdefault("zoneBasedFW", zoneBasedFW)
    policyDef.setdefault("urlFiltering", urlFiltering)
    policyDef.setdefault("intrusionPrevention", intrusionPrevention)


    ##print(policy)
    ##print(hsl)
    ##print(slogging)
    ##print(policyDef)

    payload = baseSPolicyPayload(policy['policyName'],
                policyDescription= policy['policyDescription'],
                hslServerIp=hsl['serverIp'], hslVrf=hsl['vrf'], hslPort=hsl['port'],
                loggingVpn=slogging['vpn'], loggingServerIp=slogging['serverIP'])



    for item in policyDef["zoneBasedFW"]:
        fwId = srch.getId(objType="zonebasedfw",name=item.lower())
##        print(fwId)
        if testUUID(fwId):
            payload["policyDefinition"]['assembly'].append({"type": "zoneBasedFW", "definitionId": fwId})
        else:
            print("zoneBasedFW not found!! %s" % item)
            raise SystemExit()
    ##jdump(sPolicy)
    for item in policyDef["urlFiltering"]:
        fwId = srch.getId(objType="urlFiltering",name=item.lower())
##        print(fwId)
        if testUUID(fwId):
            payload["policyDefinition"]['assembly'].append({"type": "urlFiltering", "definitionId": fwId})
        else:
            print("urlFiltering not found!! %s" % item)
            raise SystemExit()

    return json.dumps( payload)
