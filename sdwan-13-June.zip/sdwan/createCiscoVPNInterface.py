#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
# File:        createCiscoVPNInterface.py
#-------------------------------------------------------------------------------
from sdwan import *
from sdwan_utils.utils import *
from sdwan_utils.payloads import *
import csv

CONTEXT_SETTINGS = dict(token_normalize_func=lambda x: x.lower())
@click.command(context_settings=CONTEXT_SETTINGS)
@click.option("--vmanage",  '-v', prompt="vManage IP", default='10.10.20.90', required=True)
@click.option("--username", '-u', prompt="vManage Username", default='svc_api_automation', required=True)
@click.option("--password", '-p', prompt="Password", hide_input=True, required=True)
@click.option("--ciscovpninterface", '-s', prompt="Service VPN csv File", default='gs/ciscoVPNInterface.csv', required=True)
def cli(vmanage, username, password, ciscovpninterface):
    # check file exist or not
    try:
        os.lstat(ciscovpninterface)
    except FileNotFoundError as e:
        print("File not found!! %s" % ciscovpninterface)
        raise SystemExit()
##
    c90 = mySDWAN(vManage=vmanage,username=username, passcode=password)
##    srch = hcSearch(vManage=vmanage,headers=c90.headers)

    allRecords = []

    with open(ciscovpninterface, "r", encoding='utf-8-sig') as f:
        for item in csv.DictReader(f):
            allRecords.append(item)

##    print(allRecords)
    for item in allRecords:
        api = '/template/feature'
        payload = createVPNInterfacePayload(item["templateName"], templateDescription=item["templateDescription"],
                ifName=item["interfaceName"], interfaceDescription=item["interfaceDescription"], dhcpHelper=item['dhcpHelper'])
##        createVPNPayload(item["templateName"], item['vpn'], templateDescription=item["templateDescription"])
        res = c90.post(api=api,payload=payload)
##        print(type(res), res)
        if 'templateId' in res:
            print("created Feature Template: %s, templateId: %s" % (item["templateName"], res['templateId']))


if __name__ == "__main__":
    cli()