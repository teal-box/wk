#-------------------------------------------------------------------------------
# Name:        module4
#-------------------------------------------------------------------------------
from myXLS import *
from pathlib import Path
def main():
    _ = Path(".")
    XLfile = _ / "gs_template.xlsx"
    wb = fast_openpyxl(XLfile)
    template = wb[1]['sheet_Template']
    print(template)
    pass

if __name__ == '__main__':
    main()
