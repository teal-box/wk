#-------------------------------------------------------------------------------
# Name:        module1
#-------------------------------------------------------------------------------
t = {
    "templateId": "4f67e3b1-4a7d-403f-a72e-9c34552a6d4e",
    "templateName": "DT_Dublin_BR_C8000v",
    "templateDescription": "Device Templets For Dublin Branch",
    "deviceType": "vedge-C8000V",
    "deviceRole": "sdwan-edge",
    "configType": "template",
    "factoryDefault": False,
    "policyId": "9fee28a8-fa84-45b6-a789-d1e83d6dfde1",
    "featureTemplateUidRange": [],
    "draftMode": False,
    "connectionPreferenceRequired": True,
    "connectionPreference": True,
    "generalTemplates": [
        {
            "templateId": "2cde529b-72d7-42ba-ad08-7442ca248b4c",
            "templateType": "cedge_aaa"
        },
        {
            "templateId": "471b0692-58a4-4a79-8bfa-ab0e2b5e50cd",
            "templateType": "cisco_bfd"
        },
        {
            "templateId": "3abaaef5-7595-4a2b-aff6-9e64ebeb877a",
            "templateType": "cisco_omp"
        },
        {
            "templateId": "070f1dbd-609b-41ea-913b-89c104b25a17",
            "templateType": "cisco_security"
        },
        { ######### cisco_system
            "templateId": "b3bef7ba-32ab-4611-9beb-b8cf8a4c428c",
            "templateType": "cisco_system",
            "subTemplates": [
                {
                    "templateId": "51b86e56-ef14-4786-aa2b-6711d4747655",
                    "templateType": "cisco_logging"
                },
                {
                    "templateId": "ad7f5a84-481e-4f34-84cc-a550e3bed9b2",
                    "templateType": "cisco_ntp"
                }
            ]
        },
        { # Transport & Management VPN, Cisco VPN 0
            "templateId": "89bb9af4-7476-47d0-add2-2f6335d8410e",   ## >>> FT_Global_BR_VPN0_v2
            "templateType": "cisco_vpn",
            "subTemplates": [
                {
                    "templateId": "5b174906-2b4f-4c99-8ac1-a84e2cd889dd",
                    "templateType": "cisco_secure_internet_gateway"
                },
                {
                    "templateId": "8005d0f9-35c3-4010-a84a-53760c31eb2e",
                    "templateType": "cisco_vpn_interface"
                },
                {
                    "templateId": "253791f3-3c11-4743-b54e-02cca5bfb917",
                    "templateType": "cisco_vpn_interface"
                }
            ]
        },
        { ## Cisco VPN 512
            "templateId": "a4826cc7-6c7a-4d08-8b1c-f88a471267cf", ## FT_BR_VPN512_Global_V01
            "templateType": "cisco_vpn"
        },
        { #### Service VPN
            "templateId": "de1dc006-7824-4a13-b2fd-00c591347d0f",
            "templateType": "cisco_vpn",
            "subTemplates": [
                {
                    "templateId": "4ef6170c-51f4-435a-902a-358066208ebd",
                    "templateType": "cisco_vpn_interface"
                }
            ]
        },
        { #### Service VPN
            "templateId": "ea4d038a-6234-4932-b743-eefa127c2d0d",
            "templateType": "cisco_vpn",
            "subTemplates": [
                {
                    "templateId": "b9cb42b2-7a73-4eaf-863d-c498a76f03ec",
                    "templateType": "cisco_vpn_interface"
                }
            ]
        },
        { #### Service VPN
            "templateId": "d6a1648c-1348-452b-909e-37aeb9840b12",
            "templateType": "cisco_vpn",
            "subTemplates": [
                {
                    "templateId": "746dffff-cc16-44cf-9c69-c317f38ed30b",
                    "templateType": "cisco_ospf"
                },
                {
                    "templateId": "0945bfed-9899-456a-b205-06db202fe9d7",
                    "templateType": "cisco_vpn_interface"
                },
                {
                    "templateId": "97eefce9-71f5-4067-bea9-2a2a962fb0bd",
                    "templateType": "cisco_vpn_interface",
                    "subTemplates": [
                        {
                            "templateId": "e4dfb25b-52a1-46bd-9dac-70e51652f099",
                            "templateType": "cisco_dhcp_server"
                        }
                    ]
                },
                {
                    "templateId": "90df79ce-b3f6-4113-85c1-9ef669d7e0a6",
                    "templateType": "cisco_vpn_interface"
                },
                {
                    "templateId": "12f1d37f-e1a2-4d25-ac4a-3c018d74dddf",
                    "templateType": "cisco_vpn_interface",
                    "subTemplates": [
                        {
                            "templateId": "93d52cdf-5a7c-4acb-8433-eceb0cdc08c3",
                            "templateType": "cisco_dhcp_server"
                        }
                    ]
                },
                {
                    "templateId": "4e9865de-9601-49c3-b13b-d30ca98c079e",
                    "templateType": "cisco_vpn_interface"
                }
            ]
        },
        {
            "templateId": "bfc57c3f-23f4-424d-817c-4fcc5aff0bb1",
            "templateType": "cedge_global"
        },
        {
            "templateId": "82d79e96-b2ae-4a70-ab20-7f6aefc0cb12",
            "templateType": "cisco_banner"
        },
        {
            "templateId": "5cf21526-63b6-4eb5-b5b8-74b31bff9199",
            "templateType": "cisco_sig_credentials"
        },
        {
            "templateId": "90f14fe4-008b-43dc-91fe-57f528a53b2e",
            "templateType": "cisco_snmp"
        },
        {
            "templateId": "cc3160fe-dbc3-4efe-b6d5-fc27977d55dc",
            "templateType": "virtual-application-utd"
        }
    ],
    "securityPolicyId": "82701e53-275e-477e-b386-87b63c3c6896",
    "templateClass": "cedge"
}

# dict_keys(['templateId', 'templateName', 'templateDescription', 'deviceType', 'deviceRole', 'configType', 'factoryDefault', 'policyId', 'featureTemplateUidRange', 'draftMode', 'connectionPreferenceRequired', 'connectionPreference', 'generalTemplates', 'securityPolicyId', 'templateClass'])

def main():
    print(t['generalTemplates'])
    tId  = []
##    tId.append(t['templateId'])
    gt = t['generalTemplates']
##    for item in gt:
##        tId.append(item['templateId'])
##        if
##    pass
    for item in gt:
        print(item['templateId'], item['templateType'])
        if 'subTemplates' in item:
            for subItem in item['subTemplates']:
                print("\t",subItem['templateId'], subItem['templateType'])
if __name__ == '__main__':
    main()
