#-------------------------------------------------------------------------------
# Name:        module1
#-------------------------------------------------------------------------------

class Emp:
    def __init__(self, empId, empName):
        self.id = empId
        self.name = empName
##        super().__init__(**kwargs)

    def printEmp(self):
        print(f'Emp ID: {self.id}, Emp Name: {self.name}')

    def genPayroll(self):
        pass



class TParty:
    def __init__(self, orgName=None, **kwargs):
        self.orgName = orgName
        super().__init__(**kwargs)

    def printEmp(self):
        print(f'Emp ID: {self.id}, Emp Name: {self.name}, Emp Org: {self.orgName}')


class HrEmp(Emp):
    def __init__(self, empId, empName, hrRate=70, hrWorked=0, **kwargs ):
        super().__init__(empId, empName, **kwargs)
        self.hrRate = hrRate
        self.hrWorked = hrWorked

    def printEmp(self):
        print("-"*40)
        super().printEmp()
        print(f"Hourly Rate: {self.hrRate}, Hrs_Worked: {self.hrWorked}")
        self.genPayroll()
        print(f"Salary: {self.sal}")


    def genPayroll(self):
        self.sal = self.hrRate * self.hrWorked
        # print(f"Salary: {self.sal}")


class WkEmp(HrEmp):
    def __init__(self, empId, empName, hrRate=70, hrWorked=0, inc=0, **kwargs ):
        super().__init__(empId, empName, hrRate=hrRate, hrWorked=hrWorked, **kwargs)
        self.inc = inc

    def genPayroll(self):
        temp = self.hrRate * self.hrWorked
        self.sal = temp * (self.inc/100) + temp

    def printEmp(self):
        super().printEmp()
        print(f"Inc: {self.inc}")


class WkEmpTP(WkEmp, TParty):
    def __init__(self, **kwargs ):
        super().__init__( **kwargs )

    def genPayroll(self):
        temp = self.hrRate * self.hrWorked
        self.sal = temp * (self.inc/100) + temp

    def printEmp(self):
        #3super(WkEmp, self).printEmp()
        #super(TParty, self).printEmp()
        super().printEmp()
        print(f"Inc: {self.orgName}")


def main():
    pankaj = HrEmp('E001', "Pankaj Verma", hrRate=90, hrWorked=10)
    pankaj.printEmp()

    ronny = WkEmpTP(empId='E024', empName="Ronny Thomas", hrRate=70, hrWorked=10, inc=20,orgName="Wipro" )
    ronny.printEmp()
    pass

if __name__ == '__main__':
    main()
