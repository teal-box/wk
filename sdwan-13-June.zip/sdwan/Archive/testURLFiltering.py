#-------------------------------------------------------------------------------
# Name:        module1
#-------------------------------------------------------------------------------
from myXLS import *
import json
from pathlib import Path
from hc_SearchClass import *
from sdwan import *

def main():
    name = 'SP_Austin_BR_Router'
    c90 = mySDWAN(vManage="44.240.148.173",username='svc_api_automation', passcode='India@123')
    srch = hcSearch(c90.vManage, c90.headers)
    fwId = srch.getId(objType="securitypolicy",name=name)
    print(fwId)
    pass

if __name__ == '__main__':
    main()
