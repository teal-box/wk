#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------

import click
class toy:
    def __init__(self, name):
        self.name = name

    def hello(self):
        print(f"Hello {self.name}")

    def bye(self):
        print(f"Bye {self.name}")

@click.group
def cli():
    a = toy("Willy")

@click.command()
def hello():
    a.hello()

@click.command()
def bye():
    a.bye()

@cli.add_command(hello)
@cli.add_command(bye)

def main():
    pass

if __name__ == '__main__':
    cli()
