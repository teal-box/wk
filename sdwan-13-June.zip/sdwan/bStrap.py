import click
from sdwan import *
from hc_SearchClass import *
##@click.group()
##@click.pass_context
##def cli(ctx):
##    ctx.obj = sdwan.mySDWAN()

CONTEXT_SETTINGS = dict(token_normalize_func=lambda x: x.lower())
@click.command(context_settings=CONTEXT_SETTINGS)
@click.option("--vmanage",  '-v', prompt="vManage IP", default='44.240.148.173', required=True)
@click.option("--username", '-u', prompt="vManage Username", default='svc_api_automation', required=True)
@click.option("--password", '-p', prompt="Password", hide_input=True, required=True)
@click.option("--device",   '-d', prompt="Device uuid(CAPS)", required=True)
def cli(vmanage, username, password, device):
    device = device
    c90 = mySDWAN(vManage=vmanage,username=username, passcode=password)
    srch = hcSearch(vManage=vmanage, headers=c90.headers)
    cEdges = srch.getCertEdges()
    if device.lower() in cEdges:
        deviceFile = f'{device}.cfg'
    ##    print(cEdges)
        data = c90.getBootStrapFile(device=device.upper(),wanif='wan0')
        if "bootstrapConfig" in data:
            with open(deviceFile, "w") as f:
                f.write(data['bootstrapConfig'])
            print("Successfully generated Bootstrap for Device: %s, and filename: %s" % (device,deviceFile))
##        print(data)
    else:
        click.echo(f"Device {device} not found, Please validate again")

if __name__ == "__main__":
    cli()