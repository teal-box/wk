#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
from sdwan import *
from myXLS import *
import functools
import time, json
from sdwan_utils.utils import *
from pathlib import Path
from transform import *

def main():
    c90 = mySDWAN(vManage="10.10.20.90", username = "admin", passcode="C1sco12345", gs="")
    d = c90.get(api='/template/device')
    w= transform(d['data'],'templateName')
    print(w)




if __name__ == '__main__':
    main()