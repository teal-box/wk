from cred.cred import *
import os
from pathlib import Path
from sdwan_utils.utils import *
from sdwan import *
from myXLS import *

##def getvManageIP(configFile=None):
##    # os & pathlib modules are required
##    if not configFile:
##        _ = Path(".")
##        configFile = _ / "vManage.ini"
##    # read file and ignore # lines
##    configFile =  Path(configFile)
##    with open(configFile, "r") as f:
##        lines = f.readlines()
##    for line in lines:
##        if "#" in line and "\n" in line:
##            continue
##        if "vManage" in line:
##            if "=" in line:
##                l = line.split("=")
##                if len(l) < 2:
##                    print("Invalid format in vManage.ini file, should be vManage=10.10.20.90")
##                    print("Correct and rerun")
##                    raise SystemExit()
##                else:
##                    ip = l[1]
##                    # check for valid IP
##                    if isValidIP(ip):
##                        return ip
##            else:
##                print("Invalid format in vManage.ini file, should be vManage=10.10.20.90")
##                print("Correct and rerun")
##                raise SystemExit()



def main():
    baseDir = Path(".")
    wkGS = baseDir / "gs" / "Firewall_rule_branch_v1.2.xlsx"
    configFile = baseDir / "cred.ini"
    vManage = getvManageIP()

    print(vManage)
##
##    keyfile = r"cred\cutover.key"
##    if not  os.path.exists(keyfile):
##        print("key file doesn;t exist, Do you want to create [y/n]: ", end="")
##        response = input()
##        if response.upper() == "Y":
##            write_key(keyfile)
##        else:
##            sys.exit(255)


    writeSNMPString()
    cred = readSNMPString()

    wb = fast_openpyxl(wkGS)
    zones = wb[1]["sheet_Zone"]
    ports = wb[1]["sheet_Port"]
    dataPrefix = wb[1]["sheet_List"]

    c90 = mySDWAN(vManage=vManage, username = "admin", passcode=cred, gs="")

    print("Creating of Zones in the SD-WAN")
    for item in zones:
        zpayload = zoneItemParse(item)
        payload = createListPayload(item["name"], "zone", zpayload)
        t = c90.post(api='/template/policy/list/zone', method="POST", payload=payload, name=item['name'])



    pass

if __name__ == '__main__':
    main()
