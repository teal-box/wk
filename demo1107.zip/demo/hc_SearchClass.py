#-------------------------------------------------------------------------------
# Name:        hcSearch, to perform fast search in API
# from hcSearch import *
# Version:     1.1 27.6
#-------------------------------------------------------------------------------
from time import sleep
import requests
import json
from sdwan_utils.utils import *

def isJson(jString):
    # if jstring bytes convert to str
    if isinstance(jString, (bytes,)):
        jString = str(jString, encoding='utf-8')
        # other method byte_string.decode("utf-8")
    if not isinstance(jString, (str,)):
        return False
    try:
        json.loads(jString)
        return True
    except ValueError:
        return False

def transformLower(data, key):
    # data must be a list of dict
    if (not isinstance(data,(list,))) and len(data) == 0 and key not in data[0]:
        print("Data must be list of dict and atlead one item")
        return None
    temp = {}
    for item in data:
        temp.setdefault(item[key].lower(), item)
    return temp


class hcSearch:
    def __init__(self, vManage="", username = "", passcode=""):
        self.s = requests.Session()
        self.s.verify = False
        self.headers = {
          "Accept-Encoding": "gzip",
          "Content-Type": "application/x-www-form-urlencoded",
          "Accept": "application/json",
        }
        self.baseUrl = f"https://{vManage}/dataservice"
        payload = {
            "j_username" : username,
            "j_password" : passcode
            }
        loginAPI = f"https://{vManage}/j_security_check"
        res = self.s.post(loginAPI, headers = self.headers ,data=payload)
        if res.content != b'':
            print ("Authentication fail Please check username/password!")
            exit()

        cookies = res.headers["Set-Cookie"]
        jsessionid = cookies.split(";")
        # split to list
        token1=jsessionid[0]
        ####### Token - 2
        self.headers = {'Content-Type': "application/json",'Cookie': token1}
        token_url=f"{self.baseUrl}/client/token"
        res = self.s.get(url=token_url, headers=self.headers)
        token2=res.text
        self.headers.setdefault("X-XSRF-TOKEN", res.content)
        # search all objects during first time iniitalization and later on-Demand
        self.getAllObjects()


    def do(self, method="GET", api="", payload={}, name=None):
        url = f"{self.baseUrl}{api}"
        if method == "GET":
          response = self.s.get(url, headers = self.headers)
          if response.status_code >= 200 and response.status_code <= 299:
            if isJson(response.content):
                _ = response.json()
                if "data" in _:
                    return _["data"]
                else:
                    return _
            else:
                return response.content
          else:
            print("API Call: ", url)
            print("Not able to GET api, please check for API Token/credentials!!")
            return None


    def getDataprefix(self):
        _ = self.do(api='/template/policy/list/dataprefixfqdn')
        self.dataprefix = transformLower(_,'name')
        return self.dataprefix

    def getZone(self):
        _ = self.do(api='/template/policy/list/zone')
        self.zone = transformLower(_,'name')
        self.zone.setdefault('self', {'listId': 'self', 'name': 'self', 'type': 'zone', 'description': 'self'})
        return self.zone

    def getPort(self):
        _ = self.do(api='/template/policy/list/port')
        self.port = transformLower(_,'name')
        return self.port


    def getAllObjects(self):
        self.getDataprefix()
        self.getZone()
        self.getPort()
        self.getZonebasedfw()
        self.getUrlFiltering()
        self.getFTemplates()
        self.getTemplates()
        self.getSecurityPolicy()

    def getZonebasedfw(self):
##        "/template/policy/definition/zonebasedfw"
        _ = self.do(api='/template/policy/definition/zonebasedfw')
        self.zonebasedfw = {}
        if _ != None:
            self.zonebasedfw = transformLower(_,'name')
        return self.zonebasedfw


##definitionId

    def getCertEdges(self):
        _ = self.do(api='/certificate/vedge/list')
        self.certEdges = {}
        self.certEdges = transformLower(_,'uuid')
        return self.certEdges

    def getTemplates(self):
        _ = self.do(api='/template/device')
        self.dt = {}
        if _ != None:
            self.dt = transformLower(_,'templateName')
        return self.dt

    def getFTemplates(self):
        _ = self.do(api='/template/feature')
        self.ft = {}
        if _ != None:
            self.ft = transformLower(_,'templateName')
        return self.ft

    def getFTId(self, name=""):
        self.getFTemplates()
        name = str(name).lower()
        if name in self.ft:
            return self.ft[name]['templateId']
        else:
            return None


    def getUrlFiltering(self):
        _ = self.do(api='/template/policy/definition/urlfiltering')
        self.uFilter = {}
        if _ != None:
            self.uFilter = transformLower(_,'name')
        return self.uFilter


    def getSecurityPolicy(self):
        _ = self.do(api='/template/policy/security')
        self.sp = {}
        if _ != None:
            self.sp = transformLower(_,'policyName')
        return self.sp



    def getId(self, objType="", name=""):
        allObjTypes = ['dataprefix','zone','port','zonebasedfw','urlfiltering','ftemplate','dtemplate', 'securitypolicy']
        objType = str(objType).lower()
        name = str(name).lower()
        if objType in allObjTypes:
            if objType == 'dataprefix':
                if name in self.dataprefix:
                    return self.dataprefix[name]['listId']
                else:
                    return "DataprefixNotFound"
            elif objType == 'zone':
                if name in self.zone:
                    return self.zone[name]['listId']
                else:
                    return "ZoneNotFound"
            elif objType == 'port':
                if name in self.port:
                    return self.port[name]['listId']
                else:
                    return "PortNotFound"
            elif objType == 'zonebasedfw':
                if name in self.zonebasedfw:
                    return self.zonebasedfw[name]['definitionId']
                else:
                    print("%s ZoneBasedFWNotFound" % name)
                    return "ZoneBasedFWNotFound"
            elif objType == 'urlfiltering':
                if name in self.uFilter:
                    return self.uFilter[name]['definitionId']
                else:
                    print("%s UrlFilteringNotFound" % name)
                    return "UrlFilteringNotFound"
            elif objType == 'ftemplate':
                if name in self.ft:
                    return self.ft[name]['templateId']
                else:
                    print("%s FeatureTemplateNotFound" % name)
                    return "FeatureTemplateNotFound"
            elif objType == 'dtemplate':
                if name in self.dt:
                    return self.dt[name]['templateId']
                else:
                    print("%s DeviceTemplateNotFound" % name)
                    return "DeviceTemplateNotFound"
            elif objType == 'securitypolicy':
                if name in self.sp:
                    return self.sp[name]['policyId']
                else:
                    print("%s SecurityPolicyNotFound" % name)
                    return "SecurityPolicyNotFound"
        else:
            print("Not a valid dataType %s" % objType)
            return None