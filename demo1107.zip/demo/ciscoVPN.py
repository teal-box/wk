#-------------------------------------------------------------------------------
# Name:        module1
#-------------------------------------------------------------------------------

import urllib.parse
from sdwan import *
from hc_SearchClass import *



def searchFT(c90, templateName=None):
    c90.getAllTemplates()
    lowerKeys = sorted([key.lower() for key in c90.allTemplatesByName.keys() ])
    naturalKeys = sorted(c90.allTemplatesByName.keys())
    try:
        templateName = templateName.lower()
        idx = lowerKeys.index(templateName)
        templateName = naturalKeys[idx]
        return templateName
    except ValueError:
        print("Template %s not found!! Please check name again" % templateName)
        return None
##        raise SystemExit()


def ipv4DefaultRoute():
    # dict.setdefault("ip", return_paylod)
    return \
     {
            "route": {
                "vipType": "constant",
                "vipValue": [
                    {
                        "prefix": {
                            "vipObjectType": "object",
                            "vipType": "constant",
                            "vipValue": "0.0.0.0/0",
                            "vipVariableName": "vpn_ipv4_ip_prefix"
                        },
                        "vpn": {
                            "vipType": "constant",
                            "vipObjectType": "object",
                            "vipValue": 0
                        },
                        "priority-order": [
                            "prefix",
                            "vpn"
                        ]
                    }
                ],
                "vipObjectType": "tree",
                "vipPrimaryKey": [
                    "prefix"
                ]
            },
            "gre-route": {},
            "ipsec-route": {},
            "service-route": {}
        }



cliArgs = {
    "vmanage": "10.10.20.90",
    "username": "svc_api_automation",
    "password": "India@123"
    }
##api = 'https://10.10.20.90/dataservice/template/device/object/40ab828e-a858-4794-9cd5-2ad01215f146'
c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
##d = c90.get(api='/template/device/object/40ab828e-a858-4794-9cd5-2ad01215f146')
##print(d['generalTemplates'])
c90.getAllTemplates()
##srch = hcSearch(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
templateName = "000_VPN_300"
templateDescription = "000_VPN_300 DESCafs adfsf & Testing"
templateDescription = urllib.parse.quote(templateDescription)
params = {"id":"55993e06-e1e9-4084-a615-e5e9c4806979","name":templateName,"description":templateDescription}
api = "/template/feature/clone?" + urllib.parse.urlencode(params)

if templateName in c90.allTemplatesByName:
    print(c90.allTemplatesByName[templateName])

print("-"*80)

templateName = "VPN_200"
##    lowerKeys = sorted([key.lower() for key in c90.allTemplatesByName.keys() ])
##    naturalKeys = sorted(c90.allTemplatesByName.keys())
##    try:
##        templateName = templateName.lower()
##        idx = lowerKeys.index(templateName)
##        templateName = naturalKeys[idx]
##        templatePayload = c90.allTemplatesByName.get(templateName, None)
##
##        templatePayload.pop('deviceType')
##        templatePayload.setdefault('deviceType',['vedge-C8000V'])
##        templateDefinition = json.loads(templatePayload['templateDefinition'])
##        templatePayload.pop('templateDefinition')
##        templateDefinition['name'] = {'vipObjectType': 'object', 'vipType': 'constant', 'vipVariableName': 'vpn_name','vipValue': 'VPN_300'}
##        templateDefinition['vpn-id'] = {'vipObjectType': 'object', 'vipType': 'constant', 'vipValue': 300}
##        templatePayload.setdefault('templateDefinition',templateDefinition)
##        templateId =
##        print(templatePayload)
##    except ValueError:
##        print("Template %s not found!! Please check name again" % templateName)
##        raise SystemExit()

templateName = "VPN_200"
tName = searchFT(c90,templateName=templateName)
print(tName)
templateName = "VPN_300"
tName = searchFT(c90,templateName=templateName)
print(tName)
templateName = "vpn_200"
tName = searchFT(c90,templateName=templateName)
print(tName)

templateName = "vPn_200"
tName = searchFT(c90,templateName=templateName)
print(tName)

IPv4Route = True
if IPv4Route:
    print(ipv4DefaultRoute())

api = ''
##res = c90.post(api=api)
def main():
    pass

if __name__ == '__main__':
    main()
