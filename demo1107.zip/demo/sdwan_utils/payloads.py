import json

def createVPNInterfacePayload(templateName, templateDescription=None, ifName=None, interfaceDescription=None,
        interfaceIPV4Name=None, dhcpHelper=None):
    if not dhcpHelper or dhcpHelper=='None':
        dhcpHelper = {'vipObjectType': 'list','vipType': 'ignore','vipVariableName': 'vpn_if_dhcp_helper'}
    else: # for dual dhcpHelper IP address
        if isinstance(dhcpHelper, (str,)):
            dHelper = [f"{i}" for i in dhcpHelper.split(",")]

            dhcpHelper = {
              "vipObjectType": "list",
              "vipType": "constant",
              "vipValue": dHelper,
              "vipVariableName": "vpn_if_dhcp_helper"
            }
    payload = \
        {
            "deviceType": [
                "vedge-C8000V"
            ],
            "templateType": "cisco_vpn_interface",
            "templateMinVersion": "15.0.0",
            "gTemplateClass": "cedge",
            "templateDefinition": {
                "if-name": {
                    "vipObjectType": "object",
                    "vipType": "constant",
                    "vipValue": ifName,
                    "vipVariableName": 'vpn_if_name'
                },
                "description": {
                    "vipObjectType": "object",
                    "vipType": "constant",
                    "vipValue": interfaceDescription,
                    "vipVariableName": "vpn_if_description"
                },
                "ip": {
                    "address": {
                    "vipObjectType": "object",
                    "vipType": "variableName",
                    "vipValue": "",
                    "vipVariableName": interfaceIPV4Name
                    },
                    "secondary-address": {
                        "vipType": "ignore",
                        "vipValue": [],
                        "vipObjectType": "tree",
                        "vipPrimaryKey": [
                            "address"
                        ]
                    }
                },
                "dhcp-helper": {
                    "vipObjectType": "list",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_dhcp_helper"
                },
                "mtu": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": 1500,
                    "vipVariableName": "vpn_if_ip_mtu"
                },
                "tcp-mss-adjust": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_tcp_mss_adjust"
                },
                "mac-address": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_mac_address"
                },
                "speed": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "_empty",
                    "vipVariableName": "vpn_if_speed"
                },
                "duplex": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "_empty",
                    "vipVariableName": "vpn_if_duplex"
                },
                "shutdown": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "true",
                    "vipVariableName": "vpn_if_shutdown"
                },
                "arp-timeout": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": 1200,
                    "vipVariableName": "vpn_if_arp_timeout"
                },
                "autonegotiate": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_autonegotiate"
                },
                "shaping-rate": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "rewrite_shaping_rate"
                },
                "qos-map": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "qos_map"
                },
                "qos-map-vpn": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn-qos_map"
                },
                "tracker": {
                    "vipObjectType": "list",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_tracker"
                },
                "bandwidth-upstream": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_bandwidth_upstream"
                },
                "bandwidth-downstream": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_bandwidth_downstream"
                },
                "block-non-source-ip": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "false",
                    "vipVariableName": "vpn_if_block_non_source_ip"
                },
                "rewrite-rule": {
                    "rule-name": {
                        "vipObjectType": "object",
                        "vipType": "ignore",
                        "vipVariableName": "rewrite_rule_name"
                    }
                },
                "tloc-extension": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_tloc_extension"
                },
                "load-interval": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": 30,
                    "vipVariableName": "vpn_if_load_interval"
                },
                "icmp-redirect-disable": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "true",
                    "vipVariableName": "vpn_if_icmp_redirect_disable"
                },
                "tloc-extension-gre-from": {
                    "src-ip": {
                        "vipObjectType": "object",
                        "vipType": "ignore",
                        "vipVariableName": "vpn_if_tloc-ext_gre_from_src_ip"
                    },
                    "xconnect": {
                        "vipObjectType": "object",
                        "vipType": "ignore",
                        "vipVariableName": "vpn_if_tloc-ext_gre_from_xconnect"
                    }
                },
                "access-list": {
                    "vipType": "ignore",
                    "vipValue": [],
                    "vipObjectType": "tree",
                    "vipPrimaryKey": [
                        "direction"
                    ]
                },
                "auto-bandwidth-detect": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "false",
                    "vipVariableName": "vpn_if_auto_bandwidth_detect"
                },
                "iperf-server": {
                    "vipObjectType": "object",
                    "vipType": "ignore"
                },
                "media-type": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "_empty",
                    "vipVariableName": "vpn_if_media-type"
                },
                "intrf-mtu": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": 1500
                },
                "ip-directed-broadcast": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "false",
                    "vipVariableName": "vpn_if_ip-directed-broadcast"
                },
                "service-provider": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_service_provider"
                },
                "trustsec": {
                    "enforcement": {
                        "enable": {
                            "vipObjectType": "object",
                            "vipType": "ignore"
                        },
                        "sgt": {
                            "vipObjectType": "object",
                            "vipType": "ignore",
                            "vipVariableName": "trusted_enforcement_sgt"
                        }
                    }
                },
                "ipv6": {
                    "access-list": {
                        "vipType": "ignore",
                        "vipValue": [],
                        "vipObjectType": "tree",
                        "vipPrimaryKey": [
                            "direction"
                        ]
                    },
                    "address": {
                        "vipObjectType": "object",
                        "vipType": "ignore",
                        "vipValue": "",
                        "vipVariableName": "vpn_if_ipv6_ipv6_address"
                    },
                    "dhcp-helper-v6": {
                        "vipType": "ignore",
                        "vipValue": [],
                        "vipObjectType": "tree",
                        "vipPrimaryKey": [
                            "address"
                        ]
                    },
                    "secondary-address": {
                        "vipType": "ignore",
                        "vipValue": [],
                        "vipObjectType": "tree",
                        "vipPrimaryKey": [
                            "address"
                        ]
                    }
                },
                "arp": {
                    "ip": {
                        "vipType": "ignore",
                        "vipValue": [],
                        "vipObjectType": "tree",
                        "vipPrimaryKey": [
                            "addr"
                        ]
                    }
                },
                "vrrp": {
                    "vipType": "ignore",
                    "vipValue": [],
                    "vipObjectType": "tree",
                    "vipPrimaryKey": [
                        "grp-id"
                    ]
                },
                "ipv6-vrrp": {
                    "vipType": "ignore",
                    "vipValue": [],
                    "vipObjectType": "tree",
                    "vipPrimaryKey": [
                        "grp-id"
                    ]
                }
            },
            "factoryDefault": False,
            "feature": "vmanage-default",
            "templateName": templateName,
            "templateDescription": templateDescription
        }
    payload['templateDefinition'].pop("dhcp-helper")
    payload['templateDefinition'].setdefault("dhcp-helper", dhcpHelper)
    return json.dumps(payload)


##def createVPNPayload(templateName, vpnId, templateDescription=None, vpnName=None):
##    if vpnName == None:
##        vpnName = f"VPN_{vpnId}"
##    if vpnId.isnumeric():
##        vpnId = int(vpnId)
##    else:
##        print("Invalid VPN ID: %s, correct and run again" % vpnId)
##        raise SystemExit()
##    return json.dumps(\
##    {'deviceType': ['vedge-C8000V'],
##     'factoryDefault': False,
##     'templateDefinition': {'ecmp-hash-key': {'layer4': {'vipObjectType': 'object',
##                                                         'vipType': 'ignore',
##                                                         'vipValue': 'false',
##                                                         'vipVariableName': 'vpn_layer4'}},
##                            'host': {'vipObjectType': 'tree',
##                                     'vipPrimaryKey': ['hostname'],
##                                     'vipType': 'ignore',
##                                     'vipValue': []},
##                            'ip': {'gre-route': {},
##                                   'ipsec-route': {},
##                                   'service-route': {}},
##                            'ipv6': {},
##                            'name': {'vipObjectType': 'object',
##                                     'vipType': 'constant',
##                                     'vipValue': vpnName,
##                                     'vipVariableName': 'vpn_name'},
##                            'nat64': {'v4': {'pool': {'vipObjectType': 'tree',
##                                                      'vipPrimaryKey': ['name'],
##                                                      'vipType': 'ignore',
##                                                      'vipValue': []}}},
##                            'nat64-global': {'prefix': {'stateful': {}}},
##                            'omp': {'advertise': {'vipObjectType': 'tree',
##                                                  'vipPrimaryKey': ['protocol'],
##                                                  'vipType': 'ignore',
##                                                  'vipValue': []},
##                                    'distance': {'vipObjectType': 'object',
##                                                 'vipType': 'ignore',
##                                                 'vipValue': '',
##                                                 'vipVariableName': 'vpn_distance'},
##                                    'ipv6-advertise': {'vipObjectType': 'tree',
##                                                       'vipPrimaryKey': ['protocol'],
##                                                       'vipType': 'ignore',
##                                                       'vipValue': []}},
##                            'route-export': {'vipObjectType': 'tree',
##                                             'vipPrimaryKey': ['protocol'],
##                                             'vipType': 'ignore',
##                                             'vipValue': []},
##                            'route-import': {'vipObjectType': 'tree',
##                                             'vipPrimaryKey': ['protocol'],
##                                             'vipType': 'ignore',
##                                             'vipValue': []},
##                            'route-import-service': {'from': {'vipObjectType': 'tree',
##                                                              'vipPrimaryKey': ['vpn',
##                                                                                'protocol'],
##                                                              'vipType': 'ignore',
##                                                              'vipValue': []}},
##                            'service': {'vipObjectType': 'tree',
##                                        'vipPrimaryKey': ['svc-type'],
##                                        'vipType': 'ignore',
##                                        'vipValue': []},
##                            'tcp-optimization': {'vipObjectType': 'node-only',
##                                                 'vipType': 'ignore',
##                                                 'vipValue': 'false',
##                                                 'vipVariableName': 'vpn_tcp_optimization'},
##                            'vpn-id': {'vipObjectType': 'object',
##                                       'vipType': 'constant',
##                                       'vipValue': vpnId}},
##     'templateDescription': templateDescription,
##     'templateMinVersion': '15.0.0',
##     'templateName': templateName,
##     # 'templateType': 'vpn-vedge',
##     'templateType': 'cisco_vpn'}
##        )


def createVPNPayload(templateName, vpnId, templateDescription=None, vpnName=None):
    if vpnName == None:
        vpnName = f"VPN_{vpnId}"
    if vpnId.isnumeric():
        vpnId = int(vpnId)
    else:
        print("Invalid VPN ID: %s, correct and run again" % vpnId)
        raise SystemExit()
    return json.dumps(\
        {'deviceType': ['vedge-C8000V'],
         'factoryDefault': False,
         'templateDefinition': {'ecmp-hash-key': {'layer4': {'vipObjectType': 'object',
                                                             'vipType': 'ignore',
                                                             'vipValue': 'false',
                                                             'vipVariableName': 'vpn_layer4'}},
                                'host': {'vipObjectType': 'tree',
                                         'vipPrimaryKey': ['hostname'],
                                         'vipType': 'ignore',
                                         'vipValue': []},
                                'ip': {'gre-route': {},
                                       'ipsec-route': {},
                                       'service-route': {}},
                                'ipv6': {},
                                'name': {'vipObjectType': 'object',
                                         'vipType': 'constant',
                                         'vipValue': vpnName,
                                         'vipVariableName': 'vpn_name'},
                                'nat': {'natpool': {'vipObjectType': 'tree',
                                                    'vipPrimaryKey': ['name'],
                                                    'vipType': 'ignore',
                                                    'vipValue': []},
                                        'port-forward': {'vipObjectType': 'tree',
                                                         'vipPrimaryKey': ['source-port',
                                                                           'translate-port',
                                                                           'source-ip',
                                                                           'translate-ip',
                                                                           'proto'],
                                                         'vipType': 'ignore',
                                                         'vipValue': []},
                                        'static': {'vipObjectType': 'tree',
                                                   'vipPrimaryKey': ['source-ip',
                                                                     'translate-ip'],
                                                   'vipType': 'ignore',
                                                   'vipValue': []},
                                        'subnet-static': {'vipObjectType': 'tree',
                                                          'vipPrimaryKey': ['source-ip-subnet',
                                                                            'translate-ip-subnet'],
                                                          'vipType': 'ignore',
                                                          'vipValue': []}},
                                'nat64': {'v4': {'pool': {'vipObjectType': 'tree',
                                                          'vipPrimaryKey': ['name'],
                                                          'vipType': 'ignore',
                                                          'vipValue': []}}},
                                'nat64-global': {'prefix': {'stateful': {}}},
                                'omp': {'advertise': {'vipObjectType': 'tree',
                                                      'vipPrimaryKey': ['protocol'],
                                                      'vipType': 'ignore',
                                                      'vipValue': []},
                                        'ipv6-advertise': {'vipObjectType': 'tree',
                                                           'vipPrimaryKey': ['protocol'],
                                                           'vipType': 'ignore',
                                                           'vipValue': []}},
                                'omp-admin-distance-ipv4': {'vipObjectType': 'object',
                                                            'vipType': 'ignore',
                                                            'vipVariableName': 'vpn_omp-admin-distance-ipv4'},
                                'omp-admin-distance-ipv6': {'vipObjectType': 'object',
                                                            'vipType': 'ignore',
                                                            'vipVariableName': 'vpn_omp-admin-distance-ipv6'},
                                'org-name': {},
                                'route-export': {'vipObjectType': 'tree',
                                                 'vipPrimaryKey': ['protocol'],
                                                 'vipType': 'ignore',
                                                 'vipValue': []},
                                'route-import': {'vipObjectType': 'tree',
                                                 'vipPrimaryKey': ['protocol'],
                                                 'vipType': 'ignore',
                                                 'vipValue': []},
                                'route-import-from': {'vipObjectType': 'tree',
                                                      'vipPrimaryKey': ['protocol',
                                                                        'source-vpn'],
                                                      'vipType': 'ignore',
                                                      'vipValue': []},
                                'service': {'vipObjectType': 'tree',
                                            'vipPrimaryKey': ['svc-type'],
                                            'vipType': 'ignore',
                                            'vipValue': []},
                                'tenant-vpn-id': {},
                                'vpn-id': {'vipObjectType': 'object',
                                           'vipType': 'constant',
                                           'vipValue': vpnId}},
         'templateDescription': templateDescription,
         'templateMinVersion': '15.0.0',
         'templateName': templateName,
         'templateType': 'cisco_vpn'})

