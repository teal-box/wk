#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
# File:        cliOptions.py
## Usage:
## from sdwan_utils.cliOptions import *
##
## @click.command(context_settings=CONTEXT_SETTINGS)
## @cliOptions
## @click.option("")
#-------------------------------------------------------------------------------

import click
def composed(*decs):
    def deco(f):
        for dec in reversed(decs):
            f = dec(f)
        return f
    return deco


def cliOptions(func):
    return composed(
        click.option("--vmanage",  '-v', prompt="vManage IP", default='10.10.20.90', required=True, help='vManage IP Address'),
        click.option("--username", '-u', prompt="vManage Username", default='svc_api_automation', required=True, help='vManage Username'),
        click.option("--password", '-p', prompt="vManage Password", default='India@123', hide_input=True, required=True, help='vManage Password'),
##        click.option("--debug", default=False, required=False, help='Debug', hidden=True, is_flag=True)
    )(func)

CONTEXT_SETTINGS = dict(token_normalize_func=lambda x: x.lower())