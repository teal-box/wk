#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
from sdwan import *
from hc_SearchClass import *
import json
##def downloadBootstrapFile(sdwan, interface="GigabitEthernet1", deviceId=None):
##    interface = "GigabitEthernet1"
##    bs = f"/system/device/bootstrap/generic/devices?wanif={interface}"
##    g = sdwan.get(api=bs)
##    sdwan.downloadFile(api=f'/system/device/bootstrap/download/{g["id"]}')
# conn.request("GET", "/dataservice/system/device/bootstrap/device/UUID?configtype=cloudint&inclDefRootCert=true&version=v1", payload, headers)

# def getBootStrapFile(self, device="UUID",configtype="cloudint",inclDefRootCert=True, wanIf="", version="v1"):


def main():
    c90 = mySDWAN(vManage="10.10.20.90",username="admin", passcode="C1sco12345")
    srch = hcSearch(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    cEdges = srch.getCertEdges()
    device = 'C8K-D6997D4D-493C-4EC0-38DB-12C854CCF6B2'
    deviceFile = f'{device}.cfg'
##    print(cEdges)
    data = c90.getBootStrapFile(device=device,wanif='wan0')
    if "bootstrapConfig" in data:
        with open(deviceFile, "w") as f:
            f.write(data['bootstrapConfig'])
        print("Successfully generated Bootstrap for %s, and filename %s" % (device,deviceFile))
    print(data)

if __name__ == '__main__':
    main()
