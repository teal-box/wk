#-------------------------------------------------------------------------------
# Name:        module1
#-------------------------------------------------------------------------------
from sdwan import *
from sdwan_utils.utils import *
cliArgs = {
    "vmanage": "10.10.20.90",
    "username": "svc_api_automation",
    "password": "India@123"
    }
##api = 'https://10.10.20.90/dataservice/template/device/object/40ab828e-a858-4794-9cd5-2ad01215f146'
c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])


templateName = "CAS_FT_Global_BR_VPN190_v6"
retrunTemplate =  c90.searchFT(templateName=templateName)

templateName = "vpn_101"
retrunTemplate =  c90.searchFT(templateName=templateName)
print(retrunTemplate)
templateName = "branches"
retrunTemplate =  c90.searchFT(templateName=templateName)
print(retrunTemplate)




templateName = "FT_Global_VPN100_v3"
retrunTemplate =  c90.searchFT(templateName=templateName)
if not NoneOrBlank(retrunTemplate):
    print("Not NoneOrBlank: " ,retrunTemplate)
else:
    print("NoneOrBlank: " ,retrunTemplate)


templateName = "FT_Global_br_VPN100_v3"
retrunTemplate =  c90.searchFT(templateName=templateName)
print(retrunTemplate)
if not NoneOrBlank(retrunTemplate):
    print("Not NoneOrBlank: " ,retrunTemplate)
else:
    print("NoneOrBlank: " ,retrunTemplate)
def main():
    pass

if __name__ == '__main__':
    main()
