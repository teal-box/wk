#-------------------------------------------------------------------------------
# Name:        dtBase.py
# Version:     1.1 27.6
#-------------------------------------------------------------------------------
from myXLS import *
from pathlib import Path
from pprint import pprint
from collections import OrderedDict
import json
from hc_SearchClass import *

def is_template_exist(gt, templateId):
    # gt is a list of dict
##    print("in TEst", templateId)
    for idx, item in enumerate(gt):
        if item.get('templateId', None) == templateId:
            return True, idx
    return False, None

def getFTtemplateId(fTemplates,templateName):
    if templateName in fTemplates:
        return fTemplates[templateName]['templateId']
    else:
        None

def getlpId(lpByName,policyName):
    if policyName in lpByName:
        return lpByName[policyName]['policyId']
    else:
        None


def dtCreate(c90, cliArgs, dtTemplate="dtTemplate.xlsx"):
    fTemplates = c90.featureTemplatesByName()
    lpByName = c90.localPolicyByName()
##    srch = hcSearch(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    srch = hcSearch(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])

##    _ = Path(".")
##    gs = _ / "gs/Austin_template v2.xlsx"
    wb = fast_openpyxl(dtTemplate)
    if "sheet_DT_Template" in wb[1]:
        Sample = wb[1]["sheet_DT_Template"]
    else:
        print("in the XLS file: %s, no sheet with name DT_Template, please use standard template")
        raise SystemExit()

    # Template body creation
    t = OrderedDict("")
    t.setdefault("featureTemplateUidRange",[]) # must required
    t.setdefault("factoryDefault",False) # must required
    t.setdefault("policyId", "") # must required
    gt = [] # list of generalTemplates
    for line in Sample:
        # ignore all lines where there is no "Section" data
        if line.get("Section", None) == None or  line.get("Section", None) == "None":
            continue # check next row/line
        templateName = line.get("TemplateName", None)
        if templateName == "None":
            templateName = ""
            templateID = ""
##        if str(templateName).lower == "false":
##            templateName = "false"
##        if str(templateName).lower == "true":
##            templateName = "true"
        else:
            # search for template name and get ID
            templateID = getFTtemplateId(fTemplates,templateName)
        if line["Section"] == "template" or line["Section"] == "Security Policy" or line["Section"] == "Policy":
            if line["Section"] == "template":
                t.setdefault(line['Template'], templateName)
            if  line["Section"] == "Security Policy":
                fwId = srch.getId(objType="securitypolicy",name=templateName)
                if not NoneOrBlank(fwId) and testUUID(fwId):
                    t.setdefault(line['Template'], fwId)
                else:
                    print("Security Policy not found!! %s" % templateName)
##                    raise SystemExit()

            if line["Section"] == "Policy":
                policyId = getlpId(lpByName,templateName)
                t.setdefault(line['Template'], policyId)
            else:
                t.setdefault(line['Template'], "")

        else:
            # "templateType": "", "templateId": "" optional >> "subTemplates"
            if line['Sub-Template'] != 'None':
##                print("\t", line['Sub-Template'], line['SubTemplateName'])
                status, idx = is_template_exist(gt,templateID)
                if status:
                    if "subTemplates" in gt[idx]:
                        # add item
                        subt = gt[-1]['subTemplates']
                        templateID = getFTtemplateId(fTemplates,line["SubTemplateName"])
                        subt.append({"templateType": line["Sub-Template"], "templateId": templateID})
                        gt[-1].update({'subTemplates':subt})
                        gt[-1].move_to_end("subTemplates", last = True)
                    else:
##                        print("GT[-1]", gt[-1])
                        templateID = getFTtemplateId(fTemplates,line["SubTemplateName"])
                        gt[-1].setdefault("subTemplates", [{"templateType": line["Sub-Template"], "templateId": templateID}])
                        gt[-1].move_to_end("subTemplates", last = True)
##                        print("After GT[-1]", gt[-1])

            else:
                gt.append(OrderedDict({"templateType": line["Template"], "templateId": templateID}))

##    pprint(t)
##    pprint(gt)
    t.setdefault("generalTemplates", gt)
    # pprint(json.dumps(t, indent=2))
    return json.dumps(t, indent=2)
