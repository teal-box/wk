import click
from sdwan_utils.cliOptions import *
from sdwan_utils.myCSV import *
from sdwan import *
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--dataprefixfile", '-f', prompt="Security Policy csv File", default='gs/dataprefixIPv4.csv', required=True, help='CSV file, Default: gs/dataprefixIPv4.csv')
def cli(**cliArgs):
    # print(cliArgs["vmanage"],cliArgs["username"],cliArgs["password"],cliArgs["dataprefixfile"])
    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    allRecords = readCSV(inFile=cliArgs["dataprefixfile"])
##    for item in allRecords:
##        if not checkIPStr(item['datalist']):
##            print("Not a valid List")
##            raise SystemExit()
    for item in allRecords:
        print(item['datalist'])
        print(c90.createDataPrefix(item['prefixName'], desc=item['prefixName']+" Created by API", objType="dataprefix", ipStr=item['datalist'] ))


if __name__ == "__main__":
    cli()