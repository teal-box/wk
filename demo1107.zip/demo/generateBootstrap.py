import click
from sdwan import *
from hc_SearchClass import *

from sdwan_utils.cliOptions import *
########## End of import Section ##########
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--device",   '-d', prompt="Device uuid(CAPS)", required=True)
def cli(**cliArgs):
##    print(cliArgs["vmanage"],cliArgs["username"],cliArgs["password"],cliArgs["portfile"])
    device = device
    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    srch = hcSearch(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    cEdges = srch.getCertEdges()
    if device.lower() in cEdges:
        deviceFile = f'{device}.cfg'
    ##    print(cEdges)
        data = c90.getBootStrapFile(device=device.upper(),wanif='wan0')
        if "bootstrapConfig" in data:
            with open(deviceFile, "w") as f:
                f.write(data['bootstrapConfig'])
            print("Successfully generated Bootstrap for %s, and filename %s" % (device,deviceFile))
        print(data)
    else:
        click.echo(f"Device {device} not found, Please   validate again")

if __name__ == "__main__":
    cli()