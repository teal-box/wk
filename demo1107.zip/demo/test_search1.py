#-------------------------------------------------------------------------------
# Name:        module2
#-------------------------------------------------------------------------------
from sdwan import *
from sdwan_utils import *
from hc_SearchClass import *

c90 = mySDWAN(vManage="10.10.20.90", username = "admin", passcode="C1sco12345")
srch = hcSearch(vManage="10.10.20.90", headers=c90.headers)



def main():
    pass

if __name__ == '__main__':
    main()
