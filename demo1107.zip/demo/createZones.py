import click
import os, csv
from sdwan import *
from hc_SearchClass import *
from tabulate import tabulate
from sdwan_utils.utils import *

from sdwan_utils.cliOptions import *
########## End of import Section ##########
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--zonefile", '-z', prompt="Zone CSV File", default='gs/zoneFile.csv', required=True)
def cli(**cliArgs):
    # print(cliArgs["vmanage"],cliArgs["username"],cliArgs["password"],cliArgs["dataprefixfile"])
    # c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    zonefile = cliArgs.get("zonefile", None)

    # check file exist or not
    try:
        os.lstat(zonefile)
    except FileNotFoundError as e:
        print("File not found!! %s" % zonefile)
        raise SystemExit()
##
    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
##    hcs = hcSearch(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    with open(zonefile, "r", encoding='utf-8-sig') as f:
        for item in csv.DictReader(f):
            print(item['name'])
            zpayload = zoneItemParse(item)
            payload = createListPayload(item["name"], "zone", zpayload)
            print(payload)
            t = c90.post(api='/template/policy/list/zone', method="POST", payload=payload, name=item['name'])

if __name__ == "__main__":
    cli()