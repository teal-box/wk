#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
# File:        createCiscoVPNInterface.py
#-------------------------------------------------------------------------------
from sdwan import *
from sdwan_utils.utils import *
from sdwan_utils.payloads import *
import csv
import json

from sdwan_utils.cliOptions import *
########## End of import Section ##########
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--ciscovpninterface", '-s', prompt="Service VPN Interface csv File", default='gs/ciscoVPNInterface.csv', required=True)
def cli(**cliArgs):
    # print(cliArgs["vmanage"],cliArgs["username"],cliArgs["password"],cliArgs["dataprefixfile"])
    # c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    ciscovpninterface = cliArgs.get("ciscovpninterface", None)

    # check file exist or not
    try:
        os.lstat(ciscovpninterface)
    except FileNotFoundError as e:
        print("File not found!! %s" % ciscovpninterface)
        raise SystemExit()
##
    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
##    srch = hcSearch(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])

    allRecords = []

    with open(ciscovpninterface, "r", encoding='utf-8-sig') as f:
        for item in csv.DictReader(f):
            allRecords.append(item)

##    print(allRecords)
    for item in allRecords:
        api = '/template/feature'
        print("DHCP - helper ", item['dhcpHelper'])
        payload = createVPNInterfacePayload(item["templateName"], templateDescription=item["templateDescription"],
                ifName=item["interfaceName"], interfaceDescription=item["interfaceDescription"], interfaceIPV4Name=item["interfaceIPV4Name"], dhcpHelper=item['dhcpHelper'])
##        print(payload)
        res = c90.post(api=api,payload=payload)
##        #print(type(res), res)
        if res is not None and 'templateId' in res:
            print("created Feature Template: %s, templateId: %s" % (item["templateName"], res['templateId']))
        else:
            print("Error in creation of Cisco VPN interface: %s" % item["templateName"])


if __name__ == "__main__":
    cli()