#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
# File:        createCiscoVPN.py
# Version:     1.1 27.6
#-------------------------------------------------------------------------------
from sdwan import *
from sdwan_utils.utils import *
from sdwan_utils.payloads import *
import csv
import urllib.parse

def ipv4DefaultRoute():
    # dict.setdefault("ip", return_paylod)
    return \
     {
            "route": {
                "vipType": "constant",
                "vipValue": [
                    {
                        "prefix": {
                            "vipObjectType": "object",
                            "vipType": "constant",
                            "vipValue": "0.0.0.0/0",
                            "vipVariableName": "vpn_ipv4_ip_prefix"
                        },
                        "vpn": {
                            "vipType": "constant",
                            "vipObjectType": "object",
                            "vipValue": 0
                        },
                        "priority-order": [
                            "prefix",
                            "vpn"
                        ]
                    }
                ],
                "vipObjectType": "tree",
                "vipPrimaryKey": [
                    "prefix"
                ]
            },
            "gre-route": {},
            "ipsec-route": {},
            "service-route": {}
        }





from sdwan_utils.cliOptions import *
########## End of import Section ##########
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--servicevpnfile", '-s', prompt="Service VPN csv File", default='gs/serviceCiscoVPN.csv', required=True)
def cli(**cliArgs):
    # print(cliArgs["vmanage"],cliArgs["username"],cliArgs["password"],cliArgs["dataprefixfile"])

    servicevpnfile = cliArgs.get("servicevpnfile", None)
    # check file exist or not
    try:
        os.lstat(servicevpnfile)
    except FileNotFoundError as e:
        print("VPN Defination File not found!! %s" % servicevpnfile)
        raise SystemExit()
##
    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
##    srch = hcSearch(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])

    allRecords = []

    with open(servicevpnfile, "r", encoding='utf-8-sig') as f:
        for item in csv.DictReader(f):
            allRecords.append(item)

##    print(allRecords)
    defaultCISCOVpnTemplateId = None
    for item in allRecords:
        # validate template input data
        if validateCiscoVpnItem(item):
            # check if already found or not
            templateName = item["templateName"]
            print(validateCiscoVpnItem(item))
            retrunTemplate =  c90.searchFT(templateName=templateName)
            print("retrunTemplate: ", retrunTemplate, NoneOrBlank(retrunTemplate))
            if NoneOrBlank(retrunTemplate):
                # Need to create item
                # clone
                defaultCISCOVpnTemplateId = c90.allTemplatesByName['Default_BootStrap_Cisco_Static_VPN_Template']['templateId']
                templateDescription = item.get("templateDescription","None")
                templateDescription = urllib.parse.quote(templateDescription)
                params = {"id":defaultCISCOVpnTemplateId,"name":templateName,"description":templateDescription}
                api = "/template/feature/clone?" + urllib.parse.urlencode(params)
                print(api)
                res = c90.post(api=api)
                if "templateId" in res:
                    print("Template created successfully ")
                    templateId = res['templateId']
                    time.sleep(2)
                    retrunTemplate =  c90.searchFT(templateName=templateName)
                    print("Out ReturnTemplate: ", retrunTemplate)

                    print("ReturnTemplate: ", retrunTemplate)
                    templatePayload = c90.allTemplatesByName.get(templateName, None)
                    ######### deviceType
                    templatePayload.pop('deviceType')
                    templatePayload.setdefault('deviceType',['vedge-C8000V'])


                    ######### templateDescription
                    templatePayload.pop('templateDescription')
                    templatePayload.setdefault("templateDescription",item.get("templateDescription","None"))

                    templateDefinition = json.loads(templatePayload['templateDefinition'])
                    templatePayload.pop('templateDefinition') # remove templateDefinition as it is string

                    ######### VPN name and Id
                    templateDefinition['name'] = {'vipObjectType': 'osbject', 'vipType': 'constant', 'vipVariableName': 'vpn_name','vipValue': item.get('vpnName',"VPN_CAS")}
                    vpnId = item.get("vpn","")
                    if vpnId.isnumeric():
                        vpnId = int(vpnId)
                    else:
                        print("Invalid VPN ID: %s, correct and run again" % vpnId)
                        raise SystemExit()
                    templateDefinition['vpn-id'] = {'vipObjectType': 'object', 'vipType': 'constant', 'vipValue': vpnId}

                    ######### VPN route
                    templateDefinition.pop('ip')
                    if str(item.get('IPv4Route')).lower() == 'yes':
                        ipPayload = ipv4DefaultRoute()
                        templateDefinition.setdefault('ip', ipPayload)
                    else:
                        pass

                    templatePayload.setdefault('templateDefinition',templateDefinition)

                    api = f'/template/feature/{templateId}'
                    print(json.dumps(templatePayload))
                    res = c90.put(api=api,method="PUT", payload=json.dumps(templatePayload))
                    print(res)
            else:
                print("already exist item: %s" % templateName)

        else:
            continue

if __name__ == "__main__":
    cli()