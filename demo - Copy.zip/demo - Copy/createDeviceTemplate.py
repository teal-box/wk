#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
# File:        createDeviceTemplate.py
#-------------------------------------------------------------------------------
from sdwan import *
from sdwan_utils.utils import *
from sdwan_utils.payloads import *
import csv
from SecurityPolicyV3 import *
from dtBase import *
from sdwan_utils.cliOptions import *
########## End of import Section ##########
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--devicetemplatefile", '-d', prompt="Device Template File", default='gs/dtTemplate.xlsx', required=True)
def cli(vmanage, username, password, devicetemplatefile):
    # check file exist or not
    try:
        os.lstat(devicetemplatefile)
    except FileNotFoundError as e:
        print("File not found!! %s" % devicetemplatefile)
        raise SystemExit()
##
    c90 = mySDWAN(vManage=vmanage,username=username, passcode=password)
    payload = dtCreate(c90, dtTemplate=devicetemplatefile)
    res = c90.post(api='/template/device/feature', payload=payload)
    if 'templateId' in res:
        print("created Device Template ID: %s" %  res['templateId'])

if __name__ == "__main__":
    cli()