import click
from sdwan import *
from hc_SearchClass import *
from tabulate import tabulate


from sdwan_utils.cliOptions import *
########## End of import Section ##########
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--template", '-t', prompt="Template Name/ID", default='711e5457-99a9-4eac-aade-a7f7c431ee95', required=True)
def cli(**cliArgs):
    # print(cliArgs["vmanage"],cliArgs["username"],cliArgs["password"],cliArgs["dataprefixfile"])
    # c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    template = cliArgs.get("template", None)

    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    hcs = hcSearch(vManage=cliArgs["vmanage"],headers=c90.headers)
    allDT = hcs.getTemplates()
    _template = template.lower()
    if _template in allDT:
        templateId =  allDT[_template]['templateId']
    else:
        click.echo("%s not found, Please check Template name & run again" % template)
        raise SystemExit()
    rawData = c90.getTemplateCSV()

    rawData = rawData.get('header').get('columns')
    if rawData != None:
        with open(f"{template}_ToBeFilled.csv","w") as f:
            for item in rawData:
                f.write(item['property'])
                f.write(',')
##                print(item['property'])

if __name__ == "__main__":
    cli()