#-------------------------------------------------------------------------------
# Name:        module2
#-------------------------------------------------------------------------------
import sys
import os

import csv
from pathlib import Path
from sdwan_utils.utils import *

servicevpnfile = r"C:\work\WK\gs\serviceCiscoVPN.csv"

def validInt(num):
    if str(num).isnumeric():
        return True
    else:
        False

def test(l):
    l.append(30)

allRecords = []
with open(servicevpnfile, "r", encoding='utf-8-sig') as f:
    for item in csv.DictReader(f):
        allRecords.append(item)

##    print(allRecords)
defaultCISCOVpnTemplateId = None
['templateName', 'templateDescription', 'vpn', 'vpnName', 'IPv4Route']
for item in allRecords:
    print(validateCiscoVpnItem(item))


print(validInt(10))
print(validInt("10.2"))
print(validInt("10"))
print(validInt(10.4))
print(validInt("a40d"))

def main():
    pass
##    myList = [1,2]
##    test(myList)
##    print(myList)
##    print(notNone(''))
##    if NoneOrBlank('""'):
##        print('it is None or Blank')
##    else:
##        print('it is niether None or Blank')
##    pass

if __name__ == '__main__':
    main()
