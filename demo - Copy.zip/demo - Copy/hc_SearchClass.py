#-------------------------------------------------------------------------------
# Name:        hcSearch, to perform fast search in API
# from hc_SearchClass import *
# Version:     1.1 27.6
#-------------------------------------------------------------------------------
from time import sleep
import http.client
import json
from sdwan_utils.utils import *

def transformLower(data, key):
    # data must be a list of dict
    if (not isinstance(data,(list,))) and len(data) == 0 and key not in data[0]:
        print("Data must be list of dict and atlead one item")
        return None
    temp = {}
    for item in data:
        temp.setdefault(item[key].lower(), item)
    return temp


class hcSearch:
    def __init__(self,vManage="IP", headers=""):
        import ssl
        try:
            _create_unverified_https_context = ssl._create_unverified_context
        except AttributeError:
            # Legacy Python that doesn't verify HTTPS certificates by default
            pass
        else:
            # Handle target environment that doesn't support HTTPS verification
            ssl._create_default_https_context = _create_unverified_https_context

        self.host = vManage
        self.headers = headers
##        {
##          'Accept': 'application/json',
##          'Cookie': cookie
####          'Cookie': 'JSESSIONID=xxx'
##            }

        self.conn = http.client.HTTPSConnection(self.host, timeout=10)
        ## check if connection is established?
        payload = ''

        #################### Pull all objects of given type ########################
        self.getAllObjects()

    def do(self, api="", payload={}, name=None):
        self.conn.request("GET", api, '', headers = self.headers)
        res = self.conn.getresponse()
        if res.status >= 200 and res.status <= 299:
            data = res.read()
            _ = json.loads (data.decode("utf-8"))
            if "data" in _:
                return _["data"]
            else:
                return _

    def lomgDo(self, api="", payload={}, name=None):
        self.conn.request("GET", api, '', headers = self.headers)
        sleep(5)
        res = self.conn.getresponse()
        if res.status >= 200 and res.status <= 299:
            data = res.read()
            _ = json.loads (data.decode("utf-8"))
            if "data" in _:
                return _["data"]
            else:
                return _



    def getDataprefix(self):
        _ = self.do(api='/dataservice/template/policy/list/dataprefixfqdn')
        self.dataprefix = transformLower(_,'name')
        return self.dataprefix

    def getZone(self):
        _ = self.do(api='/dataservice/template/policy/list/zone')
        self.zone = transformLower(_,'name')
        self.zone.setdefault('self', {'listId': 'self', 'name': 'self', 'type': 'zone', 'description': 'self'})
        return self.zone

    def getPort(self):
        _ = self.do(api='/dataservice/template/policy/list/port')
        self.port = transformLower(_,'name')
        return self.port


    def getAllObjects(self):
        self.getDataprefix()
        self.getZone()
        self.getPort()
        self.getZonebasedfw()
        self.getUrlFiltering()

    def getZonebasedfw(self):
##        "/dataservice/template/policy/definition/zonebasedfw"
        _ = self.do(api='/dataservice/template/policy/definition/zonebasedfw')
        self.zonebasedfw = {}
        if _ != None:
            self.zonebasedfw = transformLower(_,'name')
        return self.zonebasedfw


##definitionId

    def getCertEdges(self):
        _ = self.do(api='/dataservice/certificate/vedge/list')
        self.certEdges = {}
        self.certEdges = transformLower(_,'uuid')
        return self.certEdges

    def getTemplates(self):
        _ = self.do(api='/dataservice/template/device')
        self.dt = {}
        if _ != None:
            self.dt = transformLower(_,'templateName')
        return self.dt

    def getFTemplates(self):
        _ = self.lomgDo(api='/dataservice/template/feature')
        self.ft = {}
        if _ != None:
            self.ft = transformLower(_,'templateName')
        return self.ft

    def getFTId(self, name=""):
        self.getFTemplates()
        name = str(name).lower()
        if name in self.ft:
            return self.ft[name]['templateId']
        else:
            return None


    def getUrlFiltering(self):
        _ = self.do(api='/template/policy/definition/urlfiltering')
        self.uFilter = {}
        if _ != None:
            self.uFilter = transformLower(_,'name')
        return self.uFilter


    def getId(self, objType="", name=""):
        allObjTypes = ['dataprefix','zone','port','dataprefixfqdn','zonebasedfw','urlFiltering']
        objType = str(objType).lower()
        name = str(name).lower()
        if objType in allObjTypes:
            if objType == allObjTypes[0]:
                if name in self.dataprefix:
                    return self.dataprefix[name]['listId']
                else:
                    return "DataprefixNotFound"
            elif objType == allObjTypes[1]:
                if name in self.zone:
                    return self.zone[name]['listId']
                else:
                    return "ZoneNotFound"
            elif objType == allObjTypes[2]:
                if name in self.port:
                    return self.port[name]['listId']
                else:
                    return "PortNotFound"
            elif objType == 'zonebasedfw':
                if name in self.zonebasedfw:
                    return self.zonebasedfw[name]['definitionId']
                else:
                    print("%s ZoneBasedFWNotFound" % name)
                    return "ZoneBasedFWNotFound"
            elif objType == 'urlFiltering':
                if name in self.uFilter:
                    return self.uFilter[name]['definitionId']
                else:
                    print("%s UrlFilteringNotFound" % name)
                    return "UrlFilteringNotFound"
        else:
            print("Not a valid dataType %s" % objType)
            return None

##s = hcSearch('10.10.20.90', 'JSESSIONID=8Y3qYY6K_Y755_dqC7uFYklD_h6Ac11Be_qtZSap.dfa48eb3-9e5b-4bca-a25a-2aace87fdf62')
##d = s.getDataprefix()
##print(s.getId(objType='dataprefix', name='DEST_DB'))
##print(s.getId(objType='zone', name='vpn'))
##print(s.getId(objType='port', name='TRAFFIC_VIDEO_OUTBOUND'))
####print(d)
##
##def main():
##    pass
##
##if __name__ == '__main__':
##    main()
