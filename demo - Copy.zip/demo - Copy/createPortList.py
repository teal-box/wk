import click
from sdwan_utils.cliOptions import *
from sdwan_utils.myCSV import *
from sdwan import *
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--portfile", '-f', prompt="Security Policy Port csv File", default='gs/portfile.csv', required=True, help='CSV file, Default: gs/portfile.csv')
def cli(**cliArgs):
##    print(cliArgs["vmanage"],cliArgs["username"],cliArgs["password"],cliArgs["portfile"])
    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    allRecords = readCSV(inFile=cliArgs["portfile"])

    for item in allRecords:
        payload=portPayload(item['name'], portStr=item['entries'])
        if payload is None:
            print("Issue in payload creation for item: %s " % item['name'])
        else:
            payload = json.dumps(payload)
            t = c90.post(api='/template/policy/list/port', method="POST", payload=payload, name=item['name'])

if __name__ == "__main__":
    cli()