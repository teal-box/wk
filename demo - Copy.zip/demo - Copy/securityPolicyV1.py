#-------------------------------------------------------------------------------
# Name:        module1
#-------------------------------------------------------------------------------
from myXLS import *
from pathlib import Path
from pprint import pprint
from collections import OrderedDict
import json


{
    "policyName": "SP_Dublin_BR_Router",
    "policyDescription": "SP_Dublin_BR_Router",
    "policyMode": "security",
    "policyType": "feature",
    "policyUseCase": "custom",
    "policyDefinition": {
        "assembly": [],
        "settings": {
            "zoneToNozoneInternet": "deny",
            "highSpeedLogging": {
                "serverIp": "10.145.248.200",
                "vrf": "100",
                "port": "2055"
            },
            "logging": [
                {
                    "vpn": "100",
                    "serverIP": "10.145.248.200"
                }
            ],
            "failureMode": "open"
        }
    }
}




def main():
    pass

if __name__ == '__main__':
    main()
