#-------------------------------------------------------------------------------
# Name:        module2
#-------------------------------------------------------------------------------
import sys
import os

import csv
from pathlib import Path
path = Path(__file__)
### Get the parent directory
##current_dir = os.path.dirname(os.path.realpath(__file__))
parent_dir = path.parent.absolute()
parent_dir = parent_dir.parent
# Add the parent directory to sys.path
##sys.path.append(parent_dir)
sys.path.insert(0, parent_dir)
### Import the module from the parent directory
##from module_dir import my_module
##
### Use a function from my_module
##my_module.my_function()
print(sys.path)
from ..sdwan import *


servicevpnfile = r"C:\work\WK\gs\serviceCiscoVPN.csv"





allRecords = []
with open(servicevpnfile, "r", encoding='utf-8-sig') as f:
    for item in csv.DictReader(f):
        allRecords.append(item)

##    print(allRecords)
defaultCISCOVpnTemplateId = None
for item in allRecords:
    print(item)
['templateName', 'templateDescription', 'vpn', 'vpnName', 'IPv4Route']




def main():
    pass

if __name__ == '__main__':
    main()
