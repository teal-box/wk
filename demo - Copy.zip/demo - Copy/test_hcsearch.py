#-------------------------------------------------------------------------------
# Name:        module1
#-------------------------------------------------------------------------------
from sdwan import *
from hc_SearchClass import *

cliArgs = {
    "vmanage": "10.10.20.90",
    "username": "svc_api_automation",
    "password": "India@123"
    }
##api = 'https://10.10.20.90/dataservice/template/device/object/40ab828e-a858-4794-9cd5-2ad01215f146'
c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
##d = c90.get(api='/template/device/object/40ab828e-a858-4794-9cd5-2ad01215f146')
##print(d['generalTemplates'])
##c90.getAllTemplates()
srch = hcSearch(c90.vManage, c90.headers)

dir(srch)


def main():
    pass

if __name__ == '__main__':
    main()
